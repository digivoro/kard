<template>
  <q-page class="flex flex-center">
    <h1>PORTADA</h1>
  </q-page>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
