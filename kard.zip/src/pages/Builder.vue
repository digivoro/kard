<template>
  <div>
    <q-page class="flex flex-center">
      <CardList />
    </q-page>
  </div>
</template>

<script>
import EssentialLink from "components/EssentialLink.vue";
import CardList from "components/CardList.vue";

export default {
  name: "Builder",

  components: {
    CardList
  },

  data() {
    return {};
  }
};
</script>

<style lang="scss" scoped></style>
