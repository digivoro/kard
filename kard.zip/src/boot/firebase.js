import Firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyAt0W80AmoYeKX1t9wXqLyyTsV-3bQKbsM",
  authDomain: "kard-37937.firebaseapp.com",
  databaseURL: "https://kard-37937.firebaseio.com",
  projectId: "kard-37937",
  storageBucket: "kard-37937.appspot.com",
  messagingSenderId: "473444441750",
  appId: "1:473444441750:web:0cfdad925cf8c8cdeaacb7",
  measurementId: "G-76RPSY912D"
};

Firebase.initializeApp(firebaseConfig);

let Auth = Firebase.auth();
let Firestore = Firebase.firestore();
let Storage = Firebase.storage();

export { Auth, Firestore, Storage };
