<template>
  <div>
    <Card
      v-for="(card, index) in cardList"
      :key="index"
      :name="card.name"
      :img="card.img"
    />
  </div>
</template>

<script>
import Card from "components/Card.vue";
import { Storage } from "../boot/firebase";

export default {
  name: "CardList",

  data: function() {
    return {
      cardList: [
        {
          name: "Carta 1",
          img: Storage.ref(
            "gs://kard-37937.appspot.com/img/sets/olimpia/108.jpg"
          )
        },
        {
          name: "Carta 2",
          img: "img2"
        }
      ]
    };
  },

  components: {
    Card
  }
};
</script>

<style lang="scss" scoped></style>
