<template>
  <div>
    <q-card><q-img :src="img"></q-img></q-card>
  </div>
</template>

<script>
export default {
  name: "Card",

  props: {
    name: String,
    img: String
  }
};
</script>

<style lang="scss" scoped></style>
