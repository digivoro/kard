import enUS from "./en-us";
import esCL from "./es-cl";

export default {
  "en-us": enUS,
  "es-cl": esCL
};
