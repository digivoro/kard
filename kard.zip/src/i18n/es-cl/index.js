export default {
  failed: "Acción fallida",
  success: "Acción exitosa"
};
